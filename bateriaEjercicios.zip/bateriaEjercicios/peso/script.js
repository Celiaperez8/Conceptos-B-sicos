"Use strict"

let peso = Number (prompt("Inserte su peso"));

let pesoLuna = peso*0.165;

console.log("El peso de la Luna: " +pesoLuna + "peso de la Tierra: " + peso);
alert("El peso en la Tierra: " + peso.toFixed(2) + "peso en la Luna: "+ pesoLuna.toFixed(2));
