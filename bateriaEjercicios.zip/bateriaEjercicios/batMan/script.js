"Use strict"

let batman = Number(prompt ("Número de votos de Batman"));
let superman =  Number(prompt ("Número de votos de Superman"));
let ironman = Number (prompt ("Número de votos de Ironman"));

for  (let i = 0; i < batman; i++) {
    console.count ("Voto para Batman");
 
}

for   (let i = 0; i < superman; i++) {
    console.count ("Voto  para Superman");

}
for  (let i = 0; i < ironman; i++) {
    console.count ("Voto para Ironman");
}






