"Use strict"

let esMayor = 8;

console.assert(esMayor >=  10, "debe de ser mayor de 10");
