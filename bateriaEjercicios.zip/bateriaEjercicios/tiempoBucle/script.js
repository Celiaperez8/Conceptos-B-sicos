"Use strict"

console.time("Proceso");

for  (let i = 0; i < 1000; i++) {}
console.timeEnd("Proceso");
