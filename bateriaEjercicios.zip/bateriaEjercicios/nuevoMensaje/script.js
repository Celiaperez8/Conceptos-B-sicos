"Use strict"
console.group("recursos");
console.log("iniciación");
console.info("página");
console.warn("warn")
console.groupEnd("");