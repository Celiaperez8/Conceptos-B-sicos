"use strict"

let aleatorio = Math.floor(Math.random() * 10) + 1;


let numero = Number (prompt("Introduce un número aleatorio del 1 al 1o"));

let intentos = 3;


for(let i = 0; i <= intentos ; i++);

