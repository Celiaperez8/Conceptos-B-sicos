"use script"

let num1 = Number(prompt("Ingrese el primer número"));
let num2 = Number(prompt("Ingrse el segundo número"));

let suma = num1+num2;
let resta = num1-num2;
let multiplicación = num1*num2;
let división = num1/num2;

console.log("La suma de " + num1 + " y " + num2 + " es:");
console.log("La resta de "+ num1 + " y " + num2 + " es:");
console.log("")