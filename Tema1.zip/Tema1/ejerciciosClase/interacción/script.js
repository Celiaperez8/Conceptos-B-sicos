"use strict"

let mensaje = prompt ("Introduce un mensaje");
let numero = Number (prompt("Número de veces que quieres que se repita."));

for (let i = 0; i<= numero; i++){
    console.count(mensaje);
}

