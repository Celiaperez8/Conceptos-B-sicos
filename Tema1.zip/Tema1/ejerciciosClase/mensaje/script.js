"use strict"

let numero = Number (prompt("Introduce un número"));
console.log(numero);

if (numero % 2 === 0){
    alert("El número es par");
}
else{
    alert("El número es impar");
}
