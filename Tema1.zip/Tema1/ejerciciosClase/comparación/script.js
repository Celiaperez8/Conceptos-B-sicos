"use strict"

let primerNumero = Number (prompt("Introduce el primer número"));
let segundoNumero = Number (prompt("Introduce el segundo número"));

if (primerNumero==segundoNumero){
    alert("El primer número es mayor que el segundo");

} else if(primerNumero<segundoNumero){
    alert("El segundo número es mayor que el primero");

}else if (primerNumero>segundoNumero){
        alert("El primer número es mayor que el segundo");
}

