"Use strict"

let edad = Number (prompt("Introduce su edad"));
let Nombre = prompt("Introduce su nombre");
let apellido = prompt("Introduce su apellido");

console.log("Su nombre: " + Nombre + " "+ apellido+ " y su edad es:" + edad);
