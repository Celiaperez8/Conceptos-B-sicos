let animales = ["chanchito", "Caballo"];

console.log(animales);
console.log(animales[0]);
animales[2] = "dragón";
console.log(animales);

animales[10]= "pez";
console.log(animales[7]);