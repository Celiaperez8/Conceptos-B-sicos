const nombre = "hola mundo";

console.log(nombre);