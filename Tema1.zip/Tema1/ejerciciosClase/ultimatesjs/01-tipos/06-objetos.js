let nombre = "Celia";
let edad = 19;

//propiedad
let personaje = {
    nombre:"Celia" ,
    edad : "19",

};

console.log(personaje);
console.log(personaje.edad);
console.log(personaje["nombre"]);

personaje.edad = 13;

personaje["llave"] = 16 ;

delete personaje.edad;
console.log(personaje);
