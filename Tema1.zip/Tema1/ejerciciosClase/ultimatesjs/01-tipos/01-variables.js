let nombre= 'Hola mundo';
let NombreCompleto = 'Celia Pérez';
let nombreCompleto = "Holaaa";
let nombre_completo = "Celia Pérez Gajete"

console.log(NombreCompleto);