let numero = 42;
console.log(numero); //esto es un comentario 
/**
 * ESTO 
 * ES UN COMENTARIO
 */

/*
HOLA 
 

*/
