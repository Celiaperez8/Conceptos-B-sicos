let numero = 42;
let nombre = "Hola mundo";
let verdadero = true;
let undef;
let nula = null;

console.log(typeof numero);
console.log(typeof nombre);
console.log(typeof verdadero);
console.log(typeof undef);
console.log(typeof nula);
