let numero = 1; 
let texto = "Hola mundo";
let verdadero = true;
let falso = false;
let noDefinido;
let underf = undefined;
let nulo = null;
