"use strict"

let edad = Number (prompt("Introduce su edad"));

if(edad >= "18"){
    alert("Es mayor de edad");
}else{
    alert("es menor de edad");
}


