"Use strict"

let frase = prompt ("Introduce una frase y el programa contará el número de palabras");

let palabras = frase.split(" ");

alert("La frase tiene " +  palabras.length + " palabras");

