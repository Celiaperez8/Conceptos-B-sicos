"Use strict"

let esMayor = 18;

console.assert(esMayor >=  21, "debe de ser mayor de 21");
