"Use strict"

let alumno = {
    nombre:"Celia",
    edad: 20,
    email:  "celia@gmail.com"};

console.assert(alumno.edad <18 , "El alumno es mayor de edad");
console.assert(alumno.edad > 18, "El alumno es menor de edad");




